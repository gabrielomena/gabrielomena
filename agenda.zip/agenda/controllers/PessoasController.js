const path = require('path')
let pessoas = []

let usuarios = [
    {username: 'gabriel', password: '123'},
    {username: 'joao', password: '3212'}
]

class PessoasController {
    static index(req,res)
    {
        res.render('index')
    }

    static login(req,res)
    {
        let auth = false
        let user = req.body
        if(user.login == usuario.username)
        {
            auth = true
        }else {
            auth = false
        }
        res.render('index',{
            auth:auth
        })
    }

    static sobre(req,res)
    {
        res.render('sobre',{
            usuarios:usuarios
        })
    }

    static store(req,res)
    {
        pessoas.push(req.body.nome)
    //     let pessoa = req.body
    //     pessoa.idade = 2022-pessoa.nascimento
    // console.log(pessoas)

        res.render('index',{
            pessoas:pessoas
        })
    }
   
}

module.exports = PessoasController