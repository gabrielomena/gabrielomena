const express = require('express')
const app = express()
const { engine } = require('express-handlebars')

app.engine('handlebars', engine())
app.set('view engine', 'handlebars')

const routes = require('./routes/routes')

app.use(express.urlencoded({extended:true}))

app.use('/', routes)

const port = 3000

app.listen(port, ()=>{
    console.log('Server Rodando na porta: '+port)
})